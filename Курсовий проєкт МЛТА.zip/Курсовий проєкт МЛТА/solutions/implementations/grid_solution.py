import math
from collections import defaultdict
from typing import Dict, List, Set, Tuple

from solutions.Solution import CircleIntersectionBaseSolution
from structs.Circle import Circle
from structs.Rectangle import Rectangle


class CircleIntersectionGridSolution(CircleIntersectionBaseSolution):
    def __init__(self, circles: List[Circle]):
        self.circles = circles
        self.grid_size = 20  
        self.grid: Dict[Tuple[int, int], Set[int]] = defaultdict(set)
        self.rectangles: List[Rectangle] = []

    def get_cell_bounds(self, circle: Circle) -> Tuple[int, int, int, int]:
        min_x = math.floor((circle.x - circle.radius) / self.grid_size)
        max_x = math.ceil((circle.x + circle.radius) / self.grid_size)
        min_y = math.floor((circle.y - circle.radius) / self.grid_size)
        max_y = math.ceil((circle.y + circle.radius) / self.grid_size)
        return min_x, max_x, min_y, max_y

    def circles_intersect(self, circle1: Circle, circle2: Circle) -> bool:
        distance = math.sqrt(
            (circle1.x - circle2.x) ** 2 + (circle1.y - circle2.y) ** 2
        )
        return distance < (circle1.radius + circle2.radius)

    def build_grid(self) -> None:
        for i, circle in enumerate(self.circles):
            min_x, max_x, min_y, max_y = self.get_cell_bounds(circle)
            
            for cell_x in range(min_x, max_x + 1):
                for cell_y in range(min_y, max_y + 1):
                    self.grid[(cell_x, cell_y)].add(i)

    def find_intersecting_circles(self) -> List[Set[int]]:
        visited = set()
        components = []

        def dfs(circle_id: int, component: Set[int]) -> None:
            visited.add(circle_id)
            component.add(circle_id)
            
            circle = self.circles[circle_id]
            min_x, max_x, min_y, max_y = self.get_cell_bounds(circle)
            
            for cell_x in range(min_x, max_x + 1):
                for cell_y in range(min_y, max_y + 1):
                    cell = (cell_x, cell_y)
                    if cell in self.grid:
                        for other_id in self.grid[cell]:
                            if other_id not in visited:
                                if self.circles_intersect(circle, self.circles[other_id]):
                                    dfs(other_id, component)

        for i in range(len(self.circles)):
            if i not in visited:
                component: Set[int] = set()
                dfs(i, component)
                components.append(component)

        return components

    def create_rectangle_for_component(self, component: Set[int]) -> Rectangle:
        min_x = min_y = float('inf')
        max_x = max_y = float('-inf')

        for circle_id in component:
            circle = self.circles[circle_id]
            min_x = min(min_x, circle.x - circle.radius)
            min_y = min(min_y, circle.y - circle.radius)
            max_x = max(max_x, circle.x + circle.radius)
            max_y = max(max_y, circle.y + circle.radius)

        points = [
            (min_x, min_y),
            (min_x, max_y),
            (max_x, max_y),
            (max_x, min_y)
        ]
        return Rectangle(points)

    def solve(self) -> Tuple[Rectangle, List[Circle]]:
        self.build_grid()
        
        components = self.find_intersecting_circles()
        
        max_area = float('-inf')
        max_rectangle: Rectangle = self.create_rectangle_for_component(set())
        max_component: Set[int] = set()

        for component in components:
            rectangle = self.create_rectangle_for_component(component)
            area = rectangle.calculate_area()
            self.rectangles.append(rectangle)
            
            if area > max_area:
                max_area = area
                max_rectangle = rectangle
                max_component = component

        circles_in_max = [self.circles[i] for i in max_component]
        return max_rectangle, circles_in_max 