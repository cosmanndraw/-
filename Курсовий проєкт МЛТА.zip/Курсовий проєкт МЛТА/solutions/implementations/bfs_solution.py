import math
from collections import deque
from typing import Deque, List, Set, Tuple

from data_structures.Graph import Graph
from solutions.Solution import CircleIntersectionBaseSolution
from structs.Circle import Circle
from structs.Rectangle import Rectangle


class CircleIntersectionBreadthFirstSolution(CircleIntersectionBaseSolution):
    def __init__(self, circles: List[Circle]):
        self.circles = circles
        self.graph = Graph()
        self.components: List[Set[int]] = []
        self.rectangles: List[Rectangle] = []

    def calculate_distance(self, circle1: Circle, circle2: Circle) -> float:
        return math.sqrt(
            (circle1.x - circle2.x) ** 2 + (circle1.y - circle2.y) ** 2
        )

    def build_intersection_graph(self) -> None:
        for i in range(len(self.circles)):
            self.graph.add_vertex(i)

        for i in range(len(self.circles)):
            for j in range(i + 1, len(self.circles)):
                distance = self.calculate_distance(
                    self.circles[i], self.circles[j]
                )
                if distance < (
                    self.circles[i].radius + self.circles[j].radius
                ):
                    self.graph.add_edge(i, j)

    def find_components(self) -> None:
        visited = set()
        
        def bfs(start: int, component: Set[int]) -> None:
            queue: Deque[int] = deque([start])
            visited.add(start)
            component.add(start)
            
            while queue:
                vertex = queue.popleft()
                for neighbor in self.graph.get_neighbors(vertex):
                    if neighbor not in visited:
                        visited.add(neighbor)
                        component.add(neighbor)
                        queue.append(neighbor)

        for vertex in self.graph.get_vertices():
            if vertex not in visited:
                component: Set[int] = set()
                bfs(vertex, component)
                self.components.append(component)

    def create_rectangle_for_component(self, component: Set[int]) -> Rectangle:
        min_x = min_y = float('inf')
        max_x = max_y = float('-inf')

        for circle_id in component:
            circle = self.circles[circle_id]
            min_x = min(min_x, circle.x - circle.radius)
            min_y = min(min_y, circle.y - circle.radius)
            max_x = max(max_x, circle.x + circle.radius)
            max_y = max(max_y, circle.y + circle.radius)

        points = [
            (min_x, min_y),
            (min_x, max_y),
            (max_x, max_y),
            (max_x, min_y)
        ]
        return Rectangle(points)

    def solve(self) -> Tuple[Rectangle, List[Circle]]:
        self.build_intersection_graph()
        
        self.find_components()
        
        max_area = float('-inf')
        max_rectangle: Rectangle = self.create_rectangle_for_component(set())
        max_component: Set[int] = set()

        for component in self.components:
            rectangle = self.create_rectangle_for_component(component)
            area = rectangle.calculate_area()
            self.rectangles.append(rectangle)
            
            if area > max_area:
                max_area = area
                max_rectangle = rectangle
                max_component = component

        circles_in_max = [self.circles[i] for i in max_component]
        return max_rectangle, circles_in_max 