import math
from abc import ABC, abstractmethod
from collections import deque
from typing import Deque, List, Set, Tuple

from data_structures.Graph import Graph
from structs.Circle import Circle
from structs.Rectangle import Rectangle


class CircleIntersectionBaseSolution(ABC):
    @abstractmethod
    def solve(self) -> Tuple[Rectangle, List[Circle]]:
        pass