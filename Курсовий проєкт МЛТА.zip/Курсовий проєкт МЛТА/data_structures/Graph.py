from typing import Dict, List, Optional, Set


class Graph:
    def __init__(self):
        self.vertices: Dict[int, Set[int]] = {}
        self.edge_weights: Dict[tuple[int, int], float] = {}

    def add_vertex(self, vertex: int) -> None:
        if vertex not in self.vertices:
            self.vertices[vertex] = set()

    def add_edge(self, vertex1: int, vertex2: int, weight: float = 1.0) -> None:
        self.add_vertex(vertex1)
        self.add_vertex(vertex2)
        self.vertices[vertex1].add(vertex2)
        self.vertices[vertex2].add(vertex1)
        self.edge_weights[(vertex1, vertex2)] = weight
        self.edge_weights[(vertex2, vertex1)] = weight

    def remove_edge(self, vertex1: int, vertex2: int) -> None:
        if vertex1 in self.vertices and vertex2 in self.vertices:
            self.vertices[vertex1].discard(vertex2)
            self.vertices[vertex2].discard(vertex1)
            self.edge_weights.pop((vertex1, vertex2), None)
            self.edge_weights.pop((vertex2, vertex1), None)

    def get_neighbors(self, vertex: int) -> Set[int]:
        return self.vertices.get(vertex, set())

    def get_edge_weight(self, vertex1: int, vertex2: int) -> Optional[float]:
        return self.edge_weights.get((vertex1, vertex2))

    def has_edge(self, vertex1: int, vertex2: int) -> bool:
        return vertex2 in self.get_neighbors(vertex1)

    def get_vertices(self) -> List[int]:
        return list(self.vertices.keys())

    def get_edges(self) -> List[tuple[int, int, float]]:
        edges = []
        for (v1, v2), weight in self.edge_weights.items():
            if v1 < v2:
                edges.append((v1, v2, weight))
        return edges 