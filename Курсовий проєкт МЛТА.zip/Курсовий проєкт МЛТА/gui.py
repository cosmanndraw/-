import json
import os
import time
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
from typing import List, Optional, Tuple

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from solutions.implementations.bfs_solution import (
    CircleIntersectionBreadthFirstSolution,
)
from solutions.implementations.grid_solution import CircleIntersectionGridSolution
from structs.Circle import Circle
from structs.CircleIO import CircleIO


class CircleIntersectionGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Вирішувач перетину кіл")
        self.root.geometry("1200x800")

        # Initialize variables
        self.circles: List[Circle] = []
        self.current_solution = None
        self.solution_result = None

        # Create main layout
        self.create_layout()

    def create_layout(self):
        # Create main frames
        control_frame = ttk.Frame(self.root, padding="5")
        control_frame.pack(side=tk.TOP, fill=tk.X)

        content_frame = ttk.Frame(self.root, padding="5")
        content_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Create control panel
        self.create_control_panel(control_frame)

        # Create content area with plot and text output
        self.create_content_area(content_frame)

    def create_control_panel(self, parent: ttk.Frame):
        # Create a frame for each row of controls
        row1 = ttk.Frame(parent)
        row1.pack(fill=tk.X, pady=2)
        row2 = ttk.Frame(parent)
        row2.pack(fill=tk.X, pady=2)
        row3 = ttk.Frame(parent)
        row3.pack(fill=tk.X, pady=2)

        # Solution selection
        ttk.Label(row1, text="Метод:").pack(side=tk.LEFT, padx=5)
        self.solution_var = tk.StringVar(value="BFS")
        solutions = ["BFS", "Grid"]
        solution_combo = ttk.Combobox(
            row1,
            textvariable=self.solution_var,
            values=solutions,
            state="readonly",
            width=10
        )
        solution_combo.pack(side=tk.LEFT, padx=5)

        # Number of circles
        ttk.Label(row1, text="Кількість кіл:").pack(side=tk.LEFT, padx=5)
        self.num_circles_var = tk.StringVar(value="100")
        ttk.Entry(row1, textvariable=self.num_circles_var, width=8).pack(side=tk.LEFT, padx=5)

        # Space bounds
        ttk.Label(row1, text="X:").pack(side=tk.LEFT, padx=5)
        self.min_x_var = tk.StringVar(value="0")
        self.max_x_var = tk.StringVar(value="1000")
        ttk.Entry(row1, textvariable=self.min_x_var, width=6).pack(side=tk.LEFT)
        ttk.Label(row1, text="до").pack(side=tk.LEFT)
        ttk.Entry(row1, textvariable=self.max_x_var, width=6).pack(side=tk.LEFT, padx=5)

        ttk.Label(row1, text="Y:").pack(side=tk.LEFT, padx=5)
        self.min_y_var = tk.StringVar(value="0")
        self.max_y_var = tk.StringVar(value="1000")
        ttk.Entry(row1, textvariable=self.min_y_var, width=6).pack(side=tk.LEFT)
        ttk.Label(row1, text="до").pack(side=tk.LEFT)
        ttk.Entry(row1, textvariable=self.max_y_var, width=6).pack(side=tk.LEFT, padx=5)

        # Radius bounds
        ttk.Label(row2, text="Радіус:").pack(side=tk.LEFT, padx=5)
        self.min_radius_var = tk.StringVar(value="5")
        self.max_radius_var = tk.StringVar(value="15")
        ttk.Entry(row2, textvariable=self.min_radius_var, width=6).pack(side=tk.LEFT)
        ttk.Label(row2, text="до").pack(side=tk.LEFT)
        ttk.Entry(row2, textvariable=self.max_radius_var, width=6).pack(side=tk.LEFT, padx=5)

        # Intersection constraints
        ttk.Label(row2, text="Перетини:").pack(side=tk.LEFT, padx=5)
        self.min_intersections_var = tk.StringVar(value="")
        self.max_intersections_var = tk.StringVar(value="")
        ttk.Label(row2, text="Мін:").pack(side=tk.LEFT)
        ttk.Entry(row2, textvariable=self.min_intersections_var, width=6).pack(side=tk.LEFT)
        ttk.Label(row2, text="Макс:").pack(side=tk.LEFT)
        ttk.Entry(row2, textvariable=self.max_intersections_var, width=6).pack(side=tk.LEFT, padx=5)

        # Buttons
        ttk.Button(
            row3,
            text="Згенерувати кола",
            command=self.generate_circles
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            row3,
            text="Вирішити",
            command=self.solve
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            row3,
            text="Зберегти у файл",
            command=self.save_to_file
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            row3,
            text="Завантажити з файлу",
            command=self.load_from_file
        ).pack(side=tk.LEFT, padx=5)

    def create_content_area(self, parent: ttk.Frame):
        # Create left frame for plot
        plot_frame = ttk.Frame(parent)
        plot_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)

        # Create right frame for text output
        text_frame = ttk.Frame(parent)
        text_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5)

        # Create matplotlib figure
        self.fig = Figure(figsize=(6, 6))
        self.ax = self.fig.add_subplot(111)
        
        # Create canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Create text output area
        ttk.Label(text_frame, text="Вивід:").pack(anchor=tk.W)
        self.text_output = scrolledtext.ScrolledText(text_frame, width=60, height=30)
        self.text_output.pack(fill=tk.BOTH, expand=True)

    def log_output(self, message: str):
        self.text_output.insert(tk.END, message + "\n")
        self.text_output.see(tk.END)

    def generate_circles(self):
        try:
            # Get parameters
            num_circles = int(self.num_circles_var.get())
            min_x = float(self.min_x_var.get())
            max_x = float(self.max_x_var.get())
            min_y = float(self.min_y_var.get())
            max_y = float(self.max_y_var.get())
            min_radius = float(self.min_radius_var.get())
            max_radius = float(self.max_radius_var.get())
            
            # Get intersection constraints
            min_intersections = None
            max_intersections = None
            if self.min_intersections_var.get():
                min_intersections = int(self.min_intersections_var.get())
            if self.max_intersections_var.get():
                max_intersections = int(self.max_intersections_var.get())

            # Generate circles
            self.circles = CircleIO.generate_circles(
                num_circles=num_circles,
                min_x=min_x,
                max_x=max_x,
                min_y=min_y,
                max_y=max_y,
                min_radius=min_radius,
                max_radius=max_radius,
                min_intersections=min_intersections,
                max_intersections=max_intersections
            )

            # Plot circles
            self.plot_circles()
            self.log_output(f"Згенеровано {len(self.circles)} кіл")
            
        except ValueError as e:
            messagebox.showerror("Помилка", str(e))
            self.log_output(f"Помилка: {str(e)}")

    def solve(self):
        if not self.circles:
            messagebox.showwarning("Попередження", "Спочатку згенеруйте або завантажте кола!")
            return

        try:
            # Create solution instance
            solution_name = self.solution_var.get()
            if solution_name == "BFS":
                self.current_solution = CircleIntersectionBreadthFirstSolution(self.circles)
            else:  # Grid
                self.current_solution = CircleIntersectionGridSolution(self.circles)

            # Solve with timing
            start_time = time.time()
            self.solution_result = self.current_solution.solve()
            end_time = time.time()
            execution_time = end_time - start_time
            
            # Plot result
            self.plot_solution()
            
            # Log results
            max_rectangle, max_circles = self.solution_result
            self.log_output(f"\nРозв'язок знайдено методом {solution_name}:")
            self.log_output(f"Час виконання: {execution_time:.3f} секунд")
            self.log_output(f"Максимальна площа прямокутника: {max_rectangle.calculate_area():.2f}")
            self.log_output(f"Кількість кіл у розв'язку: {len(max_circles)}")
            
        except Exception as e:
            messagebox.showerror("Помилка", str(e))
            self.log_output(f"Помилка: {str(e)}")

    def plot_circles(self):
        self.ax.clear()
        
        # Plot all circles
        for circle in self.circles:
            circle_patch = plt.Circle(
                (circle.x, circle.y),
                circle.radius,
                fill=False,
                color='blue',
                alpha=0.5
            )
            self.ax.add_patch(circle_patch)
        
        # Set equal aspect ratio and limits
        self.ax.set_aspect('equal')
        
        # Calculate plot limits with some padding
        all_x = [c.x for c in self.circles]
        all_y = [c.y for c in self.circles]
        
        x_min, x_max = min(all_x), max(all_x)
        y_min, y_max = min(all_y), max(all_y)
        
        padding = max(x_max - x_min, y_max - y_min) * 0.1
        self.ax.set_xlim(x_min - padding, x_max + padding)
        self.ax.set_ylim(y_min - padding, y_max + padding)
        
        # Add title
        self.ax.set_title('Кола')
        
        # Update canvas
        self.canvas.draw()

    def plot_solution(self):
        if not self.solution_result:
            return

        self.ax.clear()
        
        # Plot all circles
        for circle in self.circles:
            circle_patch = plt.Circle(
                (circle.x, circle.y),
                circle.radius,
                fill=False,
                color='blue',
                alpha=0.5
            )
            self.ax.add_patch(circle_patch)
        
        # Plot all rectangles
        for rectangle in self.current_solution.rectangles:
            points = rectangle.points
            polygon = plt.Polygon(
                points,
                fill=False,
                color='red',
                alpha=0.5
            )
            self.ax.add_patch(polygon)
        
        # Highlight the maximum rectangle and its circles
        max_rectangle, max_circles = self.solution_result
        max_points = max_rectangle.points
        max_polygon = plt.Polygon(
            max_points,
            fill=False,
            color='green',
            linewidth=2
        )
        self.ax.add_patch(max_polygon)
        
        for circle in max_circles:
            circle_patch = plt.Circle(
                (circle.x, circle.y),
                circle.radius,
                fill=False,
                color='green',
                linewidth=2
            )
            self.ax.add_patch(circle_patch)
        
        # Set equal aspect ratio and limits
        self.ax.set_aspect('equal')
        
        # Calculate plot limits with some padding
        all_x = [c.x for c in self.circles] + [
            p[0] for r in self.current_solution.rectangles for p in r.points
        ]
        all_y = [c.y for c in self.circles] + [
            p[1] for r in self.current_solution.rectangles for p in r.points
        ]
        
        x_min, x_max = min(all_x), max(all_x)
        y_min, y_max = min(all_y), max(all_y)
        
        padding = max(x_max - x_min, y_max - y_min) * 0.1
        self.ax.set_xlim(x_min - padding, x_max + padding)
        self.ax.set_ylim(y_min - padding, y_max + padding)
        
        # Add title
        self.ax.set_title('Розв\'язок')
        
        # Update canvas
        self.canvas.draw()

    def save_to_file(self):
        if not self.circles:
            messagebox.showwarning("Попередження", "Немає кіл для збереження!")
            return

        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON файли", "*.json"), ("Всі файли", "*.*")]
        )
        
        if filename:
            try:
                CircleIO.save_circles(self.circles, filename)
                messagebox.showinfo("Успіх", "Кола успішно збережено!")
                self.log_output(f"Кола збережено у файл {filename}")
            except Exception as e:
                messagebox.showerror("Помилка", f"Не вдалося зберегти кола: {str(e)}")
                self.log_output(f"Помилка збереження кіл: {str(e)}")

    def load_from_file(self):
        filename = filedialog.askopenfilename(
            filetypes=[("JSON файли", "*.json"), ("Всі файли", "*.*")]
        )
        
        if filename:
            try:
                self.circles = CircleIO.load_circles(filename)
                self.plot_circles()
                messagebox.showinfo("Успіх", "Кола успішно завантажено!")
                self.log_output(f"Кола завантажено з файлу {filename}")
            except Exception as e:
                messagebox.showerror("Помилка", f"Не вдалося завантажити кола: {str(e)}")
                self.log_output(f"Помилка завантаження кіл: {str(e)}")


def main():
    root = tk.Tk()
    app = CircleIntersectionGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main() 