class Circle:
    def __init__(self, x: float, y: float, radius: float, id: int):
        self.x = x
        self.y = y
        self.radius = radius
        self.id = id 