import json
import random
from typing import List, Optional, Tuple

from structs.Circle import Circle


class CircleIO:
    @staticmethod
    def save_circles(circles: List[Circle], filename: str) -> None:
        data = [
            {
                "x": circle.x,
                "y": circle.y,
                "radius": circle.radius,
                "id": circle.id
            }
            for circle in circles
        ]
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)

    @staticmethod
    def load_circles(filename: str) -> List[Circle]:
        with open(filename, 'r') as f:
            data = json.load(f)
        
        return [
            Circle(
                x=circle_data["x"],
                y=circle_data["y"],
                radius=circle_data["radius"],
                id=circle_data["id"]
            )
            for circle_data in data
        ]

    @staticmethod
    def generate_circles(
        num_circles: int,
        min_x: float,
        max_x: float,
        min_y: float,
        max_y: float,
        min_radius: float,
        max_radius: float,
        min_intersections: Optional[int] = None,
        max_intersections: Optional[int] = None,
        seed: Optional[int] = None
    ) -> List[Circle]:
        if seed is not None:
            random.seed(seed)

        def calculate_intersections(circle: Circle, circles: List[Circle]) -> int:
            count = 0
            for other in circles:
                if other.id != circle.id:
                    distance = ((circle.x - other.x) ** 2 + (circle.y - other.y) ** 2) ** 0.5
                    if distance < (circle.radius + other.radius):
                        count += 1
            return count

        def is_valid_placement(
            circle: Circle,
            circles: List[Circle],
            min_intersections: Optional[int],
            max_intersections: Optional[int]
        ) -> bool:
            if min_intersections is None and max_intersections is None:
                return True

            intersections = calculate_intersections(circle, circles)
            
            if min_intersections is not None and intersections < min_intersections:
                return False
            if max_intersections is not None and intersections > max_intersections:
                return False
            return True

        circles: List[Circle] = []
        max_attempts = 1000  

        for i in range(num_circles):
            attempts = 0
            while attempts < max_attempts:
                x = random.uniform(min_x, max_x)
                y = random.uniform(min_y, max_y)
                radius = random.uniform(min_radius, max_radius)
                
                new_circle = Circle(x, y, radius, i + 1)
                
                if is_valid_placement(new_circle, circles, min_intersections, max_intersections):
                    circles.append(new_circle)
                    break
                
                attempts += 1
            
            if attempts == max_attempts:
                raise ValueError(
                    f"Could not generate circle {i + 1} with given constraints. "
                    "Try relaxing the intersection constraints or increasing the space."
                )

        return circles

    @staticmethod
    def generate_test_cases(
        num_cases: int,
        circle_counts: List[int],
        space_bounds: List[Tuple[float, float, float, float]],
        radius_bounds: List[Tuple[float, float]],
        output_dir: str
    ) -> None:
        import os
        os.makedirs(output_dir, exist_ok=True)

        for i in range(num_cases):
            num_circles = random.choice(circle_counts)
            min_x, max_x, min_y, max_y = random.choice(space_bounds)
            min_radius, max_radius = random.choice(radius_bounds)

            circles = CircleIO.generate_circles(
                num_circles=num_circles,
                min_x=min_x,
                max_x=max_x,
                min_y=min_y,
                max_y=max_y,
                min_radius=min_radius,
                max_radius=max_radius
            )

            filename = os.path.join(output_dir, f"test_case_{i+1}.json")
            CircleIO.save_circles(circles, filename) 