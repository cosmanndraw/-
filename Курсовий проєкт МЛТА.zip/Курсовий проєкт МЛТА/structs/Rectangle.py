class Rectangle:
    def __init__(self, points: list[tuple[float, float]]):
        if len(points) != 4:
            raise ValueError("Rectangle must have exactly 4 points")
        self.points = points

    def calculate_area(self) -> float:
        area: float = 0.0
        for i in range(4):
            j = (i + 1) % 4
            area += self.points[i][0] * self.points[j][1]
            area -= self.points[j][0] * self.points[i][1]
        return abs(area) / 2 